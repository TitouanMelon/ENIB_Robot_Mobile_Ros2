var struct_a_message =
[
    [ "command", "struct_a_message.html#a25827e9cb2be1cdb757882bea43e0af9", null ],
    [ "data", "struct_a_message.html#a9eab91667db4d35c7231dcddf7b89a76", null ]
];