var dir_f396504afdc959660871b003fa10164d =
[
    [ "GitHub", "dir_7e17ac9cf8fba2cb04bc248c85b0ceb7.html", "dir_7e17ac9cf8fba2cb04bc248c85b0ceb7" ]
];