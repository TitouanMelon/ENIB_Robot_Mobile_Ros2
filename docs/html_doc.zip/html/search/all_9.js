var searchData=
[
  ['nb_0',['NB',['../main_8c.html#a58e95dc1eb9d6ce16f515e77beeadd58',1,'main.c']]]
];
