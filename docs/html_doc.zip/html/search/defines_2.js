var searchData=
[
  ['debug_5fmotor_0',['DEBUG_MOTOR',['../main_8c.html#a86963c34eaf4aa7d9adc6e80a33871a7',1,'main.c']]],
  ['debug_5fprintf_1',['DEBUG_PRINTF',['../main_8c.html#a2cc88864f2aaa74f3d4d09d76ac2961b',1,'main.c']]],
  ['default_5fdir_2',['DEFAULT_DIR',['../main_8c.html#a63ec0cea9c1f0ca8a7893c2c53d2fd81',1,'main.c']]],
  ['default_5fmode_3',['DEFAULT_MODE',['../main_8c.html#ab9c800875296f23bd616d7d273ff16d7',1,'main.c']]],
  ['default_5fspeed_4',['DEFAULT_SPEED',['../main_8c.html#afc945b2e8394478f97e2aabc7aebaf0e',1,'main.c']]]
];
