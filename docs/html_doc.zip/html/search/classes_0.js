var searchData=
[
  ['amessage_0',['AMessage',['../struct_a_message.html',1,'']]]
];
