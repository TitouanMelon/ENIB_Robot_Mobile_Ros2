var searchData=
[
  ['lcd_0',['LCD',['../main_8c.html#abf2d80992dcfabfd1668184c3dff2733',1,'main.c']]],
  ['lki_1',['LKi',['../main_8c.html#a9c4bf434152b94b6a99df877f3a70185',1,'main.c']]],
  ['lkp_2',['LKp',['../main_8c.html#ad0a3d11e0c5a60ce313ba4264e6eaba8',1,'main.c']]]
];
