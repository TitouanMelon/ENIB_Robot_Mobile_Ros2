var searchData=
[
  ['tab_5fspeed_0',['tab_speed',['../main_8c.html#a377891cff46d2f0a39f956b917366f95',1,'main.c']]]
];
